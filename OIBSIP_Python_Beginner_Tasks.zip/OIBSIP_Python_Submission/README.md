# OIBSIP Python Programming Internship

This submission contains three beginner-level Python tasks, chosen because they are the simplest tasks in the Python Programming track.

## Tasks
1. **Task 2 – BMI Calculator**
2. **Task 3 – Random Password Generator**
3. **Task 4 – Basic Weather App**

The OASIS INFOBYTE task list requires at least 3 of the 5 Python tasks, and the beginner tier is acceptable.

## How to run

### Task 2 – BMI Calculator
```bash
python bmi_calculator.py
```
No external libraries are required.

### Task 3 – Password Generator
```bash
python password_generator.py
```
No external libraries are required.

### Task 4 – Basic Weather App
Install requests:
```bash
pip install requests
```

Create a free OpenWeatherMap API key and paste it into `weather_app.py`:
```python
API_KEY = "YOUR_API_KEY"
```

Then run:
```bash
python weather_app.py
```

## GitHub folder structure

Use this structure inside the required `OIBSIP` repository:

OIBSIP/
- Python-Task2-BMICalculator/
- Python-Task3-PasswordGenerator/
- Python-Task4-BasicWeatherApp/

For the internship submission, add screenshots of each program running and a short README to each task folder if your evaluator asks for them.

## Demo video
For each task, record a short screen video showing:
- the program starting,
- sample input,
- the output,
- and the project folder/code.

The task list says the first 2 seconds of the video should show your full name + track + task title as a static frame.
